# Streamlit-trials-n-tribulations
A collection of streamlit pages that I made during my Erasmus+ stay in spain.

# How-To
To run this app, follow the quick start guide over at [streamlit.io](https://docs.streamlit.io/library/get-started/installation) and use as the entrypoint 'app.py'.  
